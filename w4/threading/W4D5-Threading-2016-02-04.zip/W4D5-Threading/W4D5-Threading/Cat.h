//
//  Girl.h
//  DSU
//
//  Created by Adam Dahan on 2015-08-27.
//  Copyright (c) 2015 Adam Dahan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Cat : NSObject

@property (nonatomic, strong) NSURL *url; 

@end
