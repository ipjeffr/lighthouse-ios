//
//  main.m
//  W4D5-Threading
//
//  Created by Adam Dahan on 2015-08-28.
//  Copyright (c) 2015 Adam Dahan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
