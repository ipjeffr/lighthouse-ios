//
//  ViewController.m
//  W4D5-Threading
//
//  Created by Adam Dahan on 2015-08-28.
//  Copyright (c) 2015 Adam Dahan. All rights reserved.
//

#import "ViewController.h"
#import "Cat.h"

@interface ViewController () <UITableViewDataSource, UITableViewDelegate>

@property BOOL downloadAsync;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentedControl;
@property (strong, nonatomic) NSMutableArray *tableData;

@end

@implementation ViewController

#pragma mark - View Lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    [self prepareDataModel];
    [self prepareTableView];
    [self prepareDataObjects];
}

#pragma mark - Preparation

- (void)prepareDataModel {
    self.tableData = [[NSMutableArray alloc] init];
}

- (void)prepareTableView {
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
}

- (void)prepareDataObjects {
    for (int i = 0; i < 200; i++) {
        Cat *cat = [[Cat alloc] init];
        cat.url = [NSURL URLWithString:@"https://pbs.twimg.com/profile_images/458794430200152064/XdQULww6.png"];
        [self.tableData addObject:cat];
    }
}

#pragma mark - Instance Methods

- (IBAction)segmentControlChanged:(id)sender {
    UISegmentedControl *segmentedControl = (UISegmentedControl *)sender;
    if (segmentedControl.selectedSegmentIndex == 0) {
        self.downloadAsync = NO;
    } else {
        self.downloadAsync = YES;
    }
    [self refreshTableData];
}

- (void)refreshTableData {
    [self.tableData removeAllObjects];
    [self.tableView reloadData];
    [self prepareDataObjects];
    [self.tableView reloadData];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tableData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    Cat *cat = self.tableData[indexPath.row];
    if (self.downloadAsync) {
        __block UIImage *image = nil;
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            image = [UIImage imageWithData:[NSData dataWithContentsOfURL:cat.url]];
            dispatch_sync(dispatch_get_main_queue(), ^{
                cell.imageView.image = image;
            });
        });
    } else {
        NSURLResponse *urlResponse = nil;
        NSError *error = nil;
        NSURLRequest *request = [NSURLRequest requestWithURL:cat.url];
        NSData *response = [NSURLConnection sendSynchronousRequest:request
                                                 returningResponse:&urlResponse
                                                             error:&error];
        cell.imageView.image = [UIImage imageWithData:response];
    }
    return cell;
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80.0;
}

@end